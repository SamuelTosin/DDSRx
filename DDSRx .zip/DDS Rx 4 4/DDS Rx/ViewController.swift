//
//  ViewController.swift
//  DDS Rx
//
//  Created by admin on 4/3/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var hiddenSections = Set<Int>()
    let tableViewData = [
        ["INFECTION (Rx written for 1 week)",
         "",
         "Amoxicillin (500 mg)\nDisp: 28 tabs\nSig: Take 1T q6h\nContraindications: allergy, mononucleosis\nSide effects: rash, diarrhea, nausea\nInteractions: anticoagulants, probenecid\n\nClindamycin (300 mg)*\nDisp: 28 tabs\nSig: Take 1T q6h\nContraindications: allergy\nSide effects: diarrhea, rash, nausea\nInteractions: neuromuscular blockers\n*Take w yogurt to avoid GI issues (C.Difficile)\n\nZpak (500mg)Tri-Pak *\nDisp: 1 Pack\nSig: Take 1T for 3 days\nContraindications: allergy, heart issues\nSide effects: nausea, diarrhea, stomach pain\nInteractions: anticoagulants, antiarrhythmics\n*Use with caution for patients with a history of heart issues",
         "","Sinus related Infection:",
        "Augmentin 500 mg\nDisp: 21 Tabs\nSig:Take 1T q8h\nContraindications: allergy\nSide effects: rash, diarrhea, nausea\nInteractions: anticoagulants, allopurinol",
        "",
        "ENDODONTICS",
        "",
        "Clindamycin (300 mg)*\nDisp: 28 tabs\nSig: Take 1T q6h\nContraindications: allergy\nSide effects: diarrhea, rash, nausea\nInteractions: neuromuscular blockers\n*Take w yogurt to avoid GI issues\n\nZpak (500mg)Tri-Pak *\n\nDisp: 1 Pack\nSig: Take 1T for 3 days\nContraindications: allergy, heart issues\nSide effects: nausea, diarrhea, stomach pain\nInteractions: anticoagulants, antiarrhythmics\n*Use with caution for patients with a history of heart issues",
        "",
        "PREMEDICATED PATIENTS ",
        "",
        "Amoxicillin (500mg) *\nDisp: 4 tabs\nSig: Take 4T one hour before procedure\nContraindications: allergy, mononucleosis\nSide effects: rash, diarrhea, nausea\nInteractions: anticoagulants, probenecid\n*Rx 2 Grams AMOX for ADULTS OR\n50 Mg/Kg for KIDS 1 hour before procedure. KIDS dose always < ADULT.\n\nCephalexin (500mg)\nDisp:8 Tabs\nSig:Take 4T 1h before procedure\nContraindications: allergy\nSide effects: diarrhea, rash, nausea\nInteractions: metformin, probenecid\n\nZpak (500mg)*\nDisp: 1 tab\nSig: Take 1 hour before procedure\nContraindications: allergy, heart issues\nSide effects: nausea, diarrhea, stomach pain\nInteractions: anticoagulants, antiarrhythmics\n*Use caution for patients with a history of heart issues.\n\nClindamycin(150mg)*\nDisp: 4 tabs\nSig: Take 4T one hour before procedure\nContraindications: allergy\nSide effects: diarrhea, rash, nausea\nInteractions: neuromuscular blockers\n*Rx total 600 mg CLINDA for ADULTS OR 20 Mg/Kg for KIDS 1 hour before procedure. KIDS dose always < ADULT."],
        ["MILD PAIN- OTC TYLENOL\nMODERATE PAIN- MOTRIN\nEXTREME PAIN- TYLENOL #3",
         "",
         "MILD PAIN -  TYLENOL*\nAcetaminophen (500mg)*\nSig:16 tabs\nDisp:Take 2T q6h prn\nContraindications: liver disease\nSide effects: liver damage\nInteractions: alcohol, warfarin\n*Take as directed. Do not take more than 6 tablets a day. Do not take if history of liver disease or problems. TYLENOL is recommended for pregnant patients for emergencies. Ask physician before use.",
         "",
         "MODERATE PAIN- MOTRIN*\nMotrin (600mg)\nDisp:28 tabs\nSig: Take T q6h prn\nContraindications: ulcer, allergy\nSide effects: GI bleeding, kidney damage\nInteractions: anticoagulants, diuretics\n*Ulcer alert. Should be taken with water. ",
        "",
        "EXTREME PAIN- TYLENOL #3*\nTylenol #3\nDisp 12 tabs\nSig: Take T q4h prn\nContraindications: respiratory depression, allergy\nSide effects: drowsiness, constipation\nInteractions: alcohol, CNS depressants\n*TYLENOL #3 is a mild narcotic. Please consult Licensing State guidelines and recommendations before prescribing.",
        "",
        "ANXIOLYSIS\n\nDx: ANXIETY\n\nDiazepam (5mg)*\nDisp:4 Tabs\nSig: take 1T before bed and 1T one hour before visit\nContraindications: respiratory issues, allergy\nSide effects: drowsiness, dizziness\nInteractions: CNS depressants, alcohol\n*Pt needs transportation assistance. Not for pregnant pts."],
        ["ANTIBACTERIAL RINSE Rx\nChlorhexidine Gluconate Oral Rinse 0.12%\nDisp: 16 oz.\nSig: Swish for 30 seconds twice a day\nContraindications: allergy\nSide effects: staining, taste alteration\nInteractions: none",
         "",
         "EXTRACTION SITE IRRIGATION Rx\nChlorhexidine Gluconate Oral Rinse 0.12%\nDisp: 16 oz.\nSig: Irrigate area with syringe provided 2 times per day over site.\nContraindications: allergy\nSide effects: staining, taste alteration\nInteractions: none",
         "",
         "ANTICARIES Rx\nNeutral Sodium Fluoride toothpaste 1.1 (5000 ppm)\nDisp: 2oz\nSig:Brush in teeth once per day\nComm: prevident toothpaste\nContraindications: allergy\nSide effects: rare\nInteractions: none"],
        ["ORAL FUNGUS\nDx: ORAL CANDIDIASIS",
         "",
         "Clotrimazole Troche (10 mg)*\nDisp: 70 Troches\nSig: Dissolve 1 troche in mouth 5 times per day*\nContains sucrose caries risk\nContraindications: allergy\nSide effects: local irritation/nInteractions: none",
         "",
         "Nystatin Tablets\nDisp:28 Tabs\nSig: Dissolve 1T in mouth q6h\nContraindications: allergy\nSide effects: nausea, diarrhea\nInteractions: none",
         "",
         "Dx: ANGULAR CHEILITIS\n\nNystatin & Triamcinolone cream\nDisp: 15g\nSig: apply on corners q6h until result is achieved\nContraindications: allergy, fungal infection\nSide effects: skin thinning, irritation\nInteractions: none",
        "",
        "HERPES VIRAL INFECTIONS ARE TREATED WITH IN OFFICE LOW INTENSITY LASER THERAPY & Rx\nRx BY MOUTH\nValtrex (100mg)*\nDisp:4 Tabs\nSig: Take 2T  at onset then 2T 12h later\nContraindications: HIV, renal/hepatic issues\nSide effects: headache, nausea\nInteractions: nephrotoxic drugs\n*Do not use for HIV patients or patients with renal or hepatic issues",
         "",
        "Acyclovir (200mg)\nDisp: 35 Tabs\nSig: Take 1T 5 times per day\nContraindications: allergy\nSide effects: nausea, headache\nInteractions: nephrotoxic drugs",
         "",
         "LOCALIZED TOPICAL Rx\nZovirax Ointment 5%*\nDisp: 16g\nSig: Apply q4h for 7d\nContraindications: allergy\nSide effects: local irritation\nInteractions: none\n*Do not use for renal or neurological impaired patients"],
        ["IMPORTANT DRUGS TO AVOID FOR BREASTFEEDING PTS:",
         "",
         "Atridox\nArestin\nAspirin\nBenzodiazepines\nDiphenhydramine\nMetronidazole\nDoxycycline\nTetracycline",
         "",
         "OTC Tylenol\nTopical anesthetic\nLido without epinephrine\nPeridex\nAmoxicillin\nClindamycin\n*Always get PHYSICIANS MEDICAL CLEARANCE before Tx and Rx.\n2ND TRIMESTER generally is the safest time for emergency treatments",
        "",
        "DRY MOUTH",
         "Biotene\nXylitol Lozenges\nDrink Water"],
        ["PRIMARY AGE OF ERUPTION ",
        "Upper\n8-12 months Central incisor\n9-13 months Lateral incisor\n16-22 months Canine\n13-19 months First molar\n25-33 months Second molar\nLower\n6-10 months Central incisor\n10-16 months Lateral incisor\n17-23 months Canine\n14-18 months First molar\n23-31 months Second molar",
        "",
        "MINIMAL DISTANCE FOR IMPLANTS",
        "Implant site next to tooth > 1.5 mm\nImplant site next to implant >3 mm\nBuccal  implant site > 1.5 mm\nLingual implant site > 1.5 mm\nDistance from nerves: >3mm\nMinimum thickness needed on buccal and lingual of 2mm for ideal results",
        "",
        "ABCDE's ORAL CANCER  DESCRIPTION",
        "A-Asymmetry\nB-Border (irregular, scalloped, or poorly defined)\nC-Color (Leucoplakia, Erythematous)\nD-Diameter\nE-Evolving (Changes over time)",
        "",
        "SCRIPT ABBREVIATIONS",
        "Q- Every\nH- Hour\nT- Tab\nPRN- as needed\nBID- 2 times a day\nTID- 3 times a day\nQID- 4 times a day"],
        ["DDS Rx is intended for use by dental professionals only. It is not intended for use by the general public or by individuals without proper training and qualifications in the field of dentistry. By using the DDS Rx app, the user confirms that they are a qualified dental professional and that they will only use the app for professional purposes. DDS Rx cannot be held liable for any misuse of the app by individuals who are not qualified dental professionals. Additionally, the user is responsible for ensuring that they comply with all applicable laws and regulations related to the use of the app in their jurisdiction. The user should also be aware of their professional responsibilities regarding the prescribing of drugs and should always consult other sources of information and seek the advice of a qualified professional before making any decisions based on the information provided by the app.\n\nThe DDS Rx application is to be used in conjunction with other prescription references. Other more extensive drug references are necessary for more comprehensive information detailing indications, contraindications, side effects, cross-drug interactions, as well as detailing the management of specific infections, diseases, medical conditions and side effects associated with the prescription of dental related drugs.\n\nDDS Rx is not liable for any clinical errors that may arise as a result of prescribing while using this app. It is the responsibility of the Dentist to know the drugs prescribed. Consequently, by using this app, you agree to assume all risks associated with using the app and its application. Use of this application regarding all information contained in the app, including prescribing information, is at your own risk and the user assumes all legal responsibility.\n\nCopyright @ 2023. All rights reserved.\n\nNo content on this app shall be transmitted or reproduced under any circumstances. Unauthorized distribution or reproduction will be prosecuted"],
        ["\n\nPlease donate to help us develop more apps to benifit dental professionals.\n\n"]
    ]
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.estimatedRowHeight = UITableView.automaticDimension
        self.tableView.estimatedRowHeight = 600
        
        self.tableView.setNeedsLayout()
        self.tableView.layoutIfNeeded()
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return self.tableViewData.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.hiddenSections.contains(section) {
            return 0
        }
        
        return self.tableViewData[section].count
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.layoutIfNeeded()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.font = UIFont.systemFont(ofSize: 13.0)
        
        if(indexPath.section == 7){
            let text = self.tableViewData[indexPath.section][indexPath.row]
            
            let fullString = NSMutableAttributedString(string: text)

            let image1Attachment = NSTextAttachment()
            image1Attachment.image = UIImage(named: "image_6487327")

            // wrap the attachment in its own attributed string so we can append it
            let image1String = NSAttributedString(attachment: image1Attachment)

            // add the NSTextAttachment wrapper to our full string, then add some more text.
            fullString.append(image1String)
            fullString.append(NSAttributedString(string: "\n\n"))

            // draw the result in a label
            cell.textLabel?.attributedText = fullString
            
        } else {
            cell.textLabel?.text = self.tableViewData[indexPath.section][indexPath.row]
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let sectionButton = UIButton()
        if(section == 0){
            sectionButton.setTitle("1. ANTIBIOTICS/PREMED Rx", for: .normal)
        } else if(section == 1){
            sectionButton.setTitle("2. PAIN & ANXIOLYSIS Rx", for: .normal)
        } else if(section == 2){
            sectionButton.setTitle("3. IRRIGATION & ANTICARIOUS Rx", for: .normal)
        } else if(section == 3){
            sectionButton.setTitle("4. ORAL FUNGUS/ VIRAL INFECTIONS ", for: .normal)
        } else if(section == 4){
            sectionButton.setTitle("5. PREGNANT / DRY MOUTH Rx", for: .normal)
        } else if(section == 5){
            sectionButton.setTitle("6. ERUPTION / IMPLANT/ Rx Ref", for: .normal)
        } else if(section == 6){
            sectionButton.setTitle("7. ABOUT US", for: .normal)
        } else if(section == 7){
            sectionButton.setTitle("8. DONATE", for: .normal)
        }
        
        sectionButton.backgroundColor = .systemBlue
        sectionButton.tag = section
        sectionButton.addTarget(self,
                                action: #selector(self.hideSection(sender:)),
                                for: .touchUpInside)

        return sectionButton
    }
    
    func textToImage(drawText text: String, inImage image: UIImage, atPoint point: CGPoint) -> UIImage {
        let textColor = UIColor.white
        let textFont = UIFont(name: "Helvetica Bold", size: 12)!

        let scale = UIScreen.main.scale
        UIGraphicsBeginImageContextWithOptions(image.size, false, scale)

        let textFontAttributes = [
            NSAttributedString.Key.font: textFont,
            NSAttributedString.Key.foregroundColor: textColor,
            ] as [NSAttributedString.Key : Any]
        image.draw(in: CGRect(origin: CGPoint.zero, size: image.size))

        let rect = CGRect(origin: point, size: image.size)
        text.draw(in: rect, withAttributes: textFontAttributes)

        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        return newImage!
    }
    
    @objc
    private func hideSection(sender: UIButton) {
        let section = sender.tag
        
        func indexPathsForSection() -> [IndexPath] {
            var indexPaths = [IndexPath]()
            
            for row in 0..<self.tableViewData[section].count {
                indexPaths.append(IndexPath(row: row,
                                            section: section))
            }
            
            return indexPaths
        }
        
        if self.hiddenSections.contains(section) {
            self.hiddenSections.remove(section)
            self.tableView.insertRows(at: indexPathsForSection(),
                                      with: .fade)
        } else {
            self.hiddenSections.insert(section)
            self.tableView.deleteRows(at: indexPathsForSection(),
                                      with: .fade)
        }
    }
}
