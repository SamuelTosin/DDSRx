//
//  Third.swift
//  DDD Rx Watch Watch App
//
//  Created by admin on 4/19/23.
//

import SwiftUI

struct Third: View {
    
    var selectedType: String
    
    var body: some View {
        List {
            Text("IRRIGATION & ANTICARIOUS Rx")
                .foregroundColor(.green).font(.system(size: 10))
                .multilineTextAlignment(.leading)
                .padding(.top, -20)
                .listRowBackground(Color.clear)
            Section(header: Text("ANTIBACTERIAL RINSE Rx").foregroundColor(.red).font(.system(size: 10)).multilineTextAlignment(.leading).padding(.top, -20)){

                Text("\n\nDisp: 16 oz.\nSig: Swish for 30 seconds twice a day\nContraindications: allergy\nSide effects: staining, taste alteration\nInteractions: none").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .font(.system(size: 10))
                    .listRowPlatterColor(Color.clear)
                    .overlay(
                        Text("Chlorhexidine Gluconate Oral Rinse 0.10%")
                    .underline()
                    .font(.system(size: 10))
                , alignment: .topLeading
            )
                
                Text("EXTRACTION SITE IRRIGATION Rx").font(.system(size: 10))
                    .foregroundColor(.red)
                    .listRowBackground(Color.clear)
                
                    .listRowBackground(Color.clear)
                Text("\n\nDisp: 16 oz.\nSig: Irrigate area with syringe provided 2 times per day over site.\nContraindications: allergy\nSide effects: staining, taste alteration\nInteractions: none").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                        Text("Chlorhexidine Gluconate Oral Rinse 0.10%")
                    .underline()
                    .font(.system(size: 10))
                , alignment: .topLeading
            )
                
                Text("ANTICARIES Rx").font(.system(size: 10))
                    .foregroundColor(.red)
                    .listRowBackground(Color.clear)
                
                    .listRowBackground(Color.clear).font(.system(size: 10))
                Text("\n\nDisp: 2oz\nSig: Brush in teeth once per day\nComm: prevident toothpaste\nContraindications: allergy\nSide effects: rare\nInteractions: none").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                        Text("Neutral Sodium Fluoride toothpaste 1.1 (5000 ppm)")
                    .underline()
                    .font(.system(size: 10))
                , alignment: .topLeading
            )
            }
            
        }
    }
}

struct Third_Previews: PreviewProvider {
    static var previews: some View {
        Third(selectedType: "3")
    }
}
