//
//  Fifth.swift
//  DDD Rx Watch Watch App
//
//  Created by admin on 4/19/23.
//

import SwiftUI

struct Fifth: View {
    
    var selectedType: String
    
    var body: some View {
        List{
            Text("PREGANT / DRY MOUTH Rx").foregroundColor(.green).font(.system(size: 10))
                .padding(.top, -20)
                .multilineTextAlignment(.leading)
                .listRowBackground(Color.clear)
            Section(header: Text("IMPORTANT DRUGS TO AVOID FOR BREASTFEEDING PTS:").foregroundColor(.red).font(.system(size: 10)).multilineTextAlignment(.leading).padding(.top, -20)){
                Text("Atridox\nArestin\nAspirin\nBenzodiazepines\nDiphenhydramine\nMetronidazole\nDoxycycline\nTetracycline").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                
                Text("Drugs Generally SAFE FOR PREGNANT PATINTS IN EMERGENCIES*:").font(.system(size: 10)).listRowPlatterColor(.clear).foregroundColor(.red)
                Text("OTC Tylenol\nTopical anesthetic\nLido without epinephrine\nPeridex\nAmoxicillin\nClindamycin\n*Always get PHYSICIANS MEDICAL CLEARANCE before Tx and Rx.\n2ND TRIMESTER generally is the safest time for emergency treatments").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                
                
                    .listRowBackground(Color.clear)
                

                Text("\nBiotene\nXylitol Lozenges\nDrink Water").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                        Text("DRY MOUTH")
                            .foregroundColor(.red)
                .font(.system(size: 10))
                , alignment: .topLeading
            )
            }
            
        }    }
}

struct Fifth_Previews: PreviewProvider {
    static var previews: some View {
        Fifth(selectedType: "5")
    }
}
