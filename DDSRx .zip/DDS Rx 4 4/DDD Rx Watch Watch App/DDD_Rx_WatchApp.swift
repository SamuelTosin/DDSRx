//
//  DDD_Rx_WatchApp.swift
//  DDD Rx Watch Watch App
//
//  Created by admin on 4/19/23.
//

import SwiftUI

@main
struct DDD_Rx_Watch_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
