//
//  Eight.swift
//  DDD Rx Watch Watch App
//
//  Created by admin on 4/19/23.
//

import SwiftUI

struct Eight: View {
    
    var selectedType: String
    
    var body: some View {
            
        VStack {
            Text("DONATE")
                .foregroundColor(.green)
                .multilineTextAlignment(.leading)
                .listRowBackground(Color.clear)
            Text("Please donate to help us develop more apps to benefit dental professionals.").font(.system(size: 12))
                       .padding()
                   
                   Image("image_6487327")
                       .resizable()
                       .frame(width: 100, height: 100)
                       .scaledToFit()
                       .padding(.bottom)
               }
           }
}



struct Eight_Previews: PreviewProvider {
    static var previews: some View {
        Eight(selectedType: "8")
    }
}
