//
//  Fix.swift
//  DDD Rx Watch Watch App
//
//  Created by admin on 4/19/23.
//

import SwiftUI

struct Fix: View {
    
    var selectedType: String
    
    var body: some View {
        List{
            Text("ERUPTION/IMPLANT / Rx Ref").font(.system(size: 10))
                .foregroundColor(.green)
                .padding(.top, -20)
                .listRowBackground(Color.clear)
            Section(header: Text("PRIMARY AGE OF ERUPTION").foregroundColor(.red).padding(.top, -20).font(.system(size: 10))){
                        Text("\n8-10 months Central incisor \n9-13 months Lateral incisor\n16-22 months Canine\n13-19 months First molar\n25-33 months Second molar").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                        Text("Upper")
                .font(.system(size: 10))
                , alignment: .topLeading
            )
                
                Text("\n6-10 months Central incisor \n10-16 months Lateral incisor\n17-23 months Canine\n14-18 months First molar\n23-31 months Second molar").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                        Text("Lower")
                .font(.system(size: 10))
                , alignment: .topLeading
            )
                

                
                        Text("\n\nImplant site next to tooth > 1.5 mm\n Implant site next to implant > 3 mm\n Buccal implant site > 1.5 mm\n Lingual implant site > 1.5 mm\n Distance from nerves: > 3 mm\n Minimum thickness needed on buccal and lingual of 2 mm for ideal results\n").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                        Text("MINIMAL DISTANCE FOR IMPLANTS")
                .font(.system(size: 10))
                .foregroundColor(.red)
                , alignment: .topLeading
            )

                
                            .listRowBackground(Color.clear)
                Text("\n\nA-Asymmetry\nB-Border (irregular, scalloped, or poorly defined)\nC-Color (Leucoplakia, Erythematous)\nD-Diameter\nE-Evolving (Changes over time)").font(.system(size: 10))
                    .overlay(
                        Text("ABCDE's ORAL CANCER DESCRIPTION")
                .font(.system(size: 10))
                .foregroundColor(.red)
                , alignment: .topLeading
            )
            }
            
            .listRowBackground(Color.clear)

                    Section {
                        Text("\n\nQ- Every\nH- Hour\nT- Tab\nPRN- as needed\nBID- 2 times a day\nTID- 3 times a day\nQID- 4 times a day)").font(.system(size: 10))
                            .overlay(
                                Text("SCRIPT ABBREVIATIONS")
                        .font(.system(size: 10))
                        .foregroundColor(.red)
                        , alignment: .topLeading
                    )
                            }
                            .listRowBackground(Color.clear)

                }
            
        }
}

struct Fix_Previews: PreviewProvider {
    static var previews: some View {
        Fix(selectedType: "6")
    }
}
