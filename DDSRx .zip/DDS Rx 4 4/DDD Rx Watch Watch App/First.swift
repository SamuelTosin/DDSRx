    //
//  First.swift
//  DDD Rx Watch Watch App
//
//  Created by admin on 4/19/23.
//

import SwiftUI

struct First: View {
    
    var selectedType: String
    
    var body: some View {
        List {
            Text("PAIN & ANXIOLYSIS Rx").foregroundColor(.green).font(.system(size: 10))
                .multilineTextAlignment(.leading)
                .listRowBackground(Color.clear)

            Text("INFECTION (Rx written for 1 week)").foregroundColor(.red).font(.system(size: 10)).multilineTextAlignment(.leading).padding(.top, -20).listRowPlatterColor(.clear)
                    
                Text("Disp: 28 tabs\nSig: Take 1T q6h\nContraindications: allergy, mononucleosis\nSide effects: rash, diarrhea, nausea\nInteractions: anticoagulants, probenecid")
                    .font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                        Text("Amoxicillin (500 mg)")
                            .padding(.top, -20)
                            .underline()
                            .font(.system(size: 10))
                        , alignment: .topLeading
                    )


                    .listRowBackground(Color.clear)
                        Text("\nDisp: 28 tabs\nSig: Take 1T q6h\nContraindications: allergy\nSide effects: diarrhea, rash, nausea\nInteractions: neuromuscular blockers\n*Take w yogurt to avoid GI issues (C.Difficile)").font(.system(size: 10))
                    .overlay(
                        Text("Clindamycin (300 mg)*")
                            .underline()
                            .font(.system(size: 10))
                        , alignment: .topLeading
                    )
                
                    .listRowBackground(Color.clear)

                            .listRowBackground(Color.clear)
                        Text("\nDisp: 1 Pack\nSig: Take 1T for 3 days\nContraindications: allergy, heart issues\nSide effects: nausea, diarrhea, stomach pain\nInteractions: anticoagulants, antiarrhythmics\n*Use with caution for patients with a history of heart issues").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                        Text("Zpak (500mg)Tri-Pak*")
                            .underline()
                            .font(.system(size: 10))
                        , alignment: .topLeading
                    )


                        Text("Sinus related Infection:").font(.system(size: 10))
                    .foregroundColor(.red)
                    .padding(.top, -20)
                    .listRowPlatterColor(.clear)
            
                        Text("Disp: 21 Tabs\nSig:Take 1T q8h\nContraindications: allergy\nSide effects: rash, diarrhea, nausea\nInteractions: anticoagulants, allopurinol").font(.system(size: 10))
                            .listRowBackground(Color.clear)
                
                            .overlay(
                                Text("Augmentin 500 mg*")
                                    .padding(.top, -20)

                                    .underline()
                                    .font(.system(size: 10))
                                , alignment: .topLeading
                            )
                    

            Section() {
                Text("ENDODONTICS").font(.system(size: 10)).listRowPlatterColor(.clear).foregroundColor(.red)
                            .listRowBackground(Color.clear)

                        Text("\nDisp: 28 tabs\nSig: Take 1T q6h\nContraindications: allergy\nSide effects: diarrhea, rash, nausea\nInteractions: neuromuscular blockers\n*Take w yogurt to avoid GI issues").font(.system(size: 10))
                            .listRowBackground(Color.clear)
                            .overlay(
                                Text("Clindamycin (300 mg)*")
                                    .underline()
                                    .font(.system(size: 10))
                                , alignment: .topLeading
                            )

                            .listRowBackground(Color.clear)

                        Text("\nDisp: 1 Pack\nSig: Take 1T for 3 days\nContraindications: allergy, heart issues\nSide effects: nausea, diarrhea, stomach pain\nInteractions: anticoagulants, antiarrhythmics\n*Use with caution for patients with a history of heart issues").font(.system(size: 10))
                            .listRowBackground(Color.clear)
                            .overlay(
                                Text("Zpak (500mg)Tri-Pak*")
                                    .underline()
                                    .font(.system(size: 10))
                                , alignment: .topLeading
                            )

                Text("PREMEDICATED PATIENTS").font(.system(size: 10))
                            .listRowBackground(Color.clear)
                            .foregroundColor(.red)

                            .listRowBackground(Color.clear)

                        Text("\nDisp: 4 tabs\nSig: Take 4T one hour before procedure\nContraindications: allergy, mononucleosis\nSide effects: rash, diarrhea, nausea\nInteractions: anticoagulants, probenecid\n*Rx 2 Grams AMOX for ADULTS OR\n50 Mg/Kg for KIDS 1 hour before procedure. KIDS dose always < ADULT.").font(.system(size: 10))
                            .listRowBackground(Color.clear)
                            .overlay(
                                Text("Amoxicillin (500mg)*")
                                    .underline()
                                    .font(.system(size: 10))
                                , alignment: .topLeading
                            )

                            .listRowBackground(Color.clear)

                        Text("\nDisp:8 Tabs\nSig:Take 4T 1h before procedure\nContraindications: allergy\nSide effects: diarrhea, rash, nausea\nInteractions: metformin, probenecid").font(.system(size: 10))
                            .listRowBackground(Color.clear)
                            .overlay(
                                Text("Cephalexin (500mg)*")
                                    .underline()
                                    .font(.system(size: 10))
                                , alignment: .topLeading
                            )

                    }

                    Section {

                        Text("\nDisp: 1 tab\nSig: Take 1 hour before procedure\nContraindications: allergy, heart issues\nSide effects: nausea, diarrhea, stomach pain\nInteractions: anticoagulants, antiarrhythmics\n*Use caution for patients with a history of heart issues").font(.system(size: 10))
                            .listRowBackground(Color.clear)
                            .overlay(
                                Text("Zpak (500mg)*")
                                    .underline()
                                    .font(.system(size: 10))
                                , alignment: .topLeading
                            )

                            .listRowBackground(Color.clear)

                        Text("\nDisp: 4 tabs\nSig: Take 4T one hour before procedure\nContraindications: allergy\nSide effects: diarrhea, rash, nausea\nInteractions: neuromuscular blockers\n*Rx total 600 mg CLINDA for ADULTS OR 20 Mg/Kg for KIDS 1 hour before procedure. KIDS dose always < ADULT.").font(.system(size: 10))
                            .listRowBackground(Color.clear)
                            .overlay(
                                Text("Clindamycin(150mg)*")
                                    .underline()
                                    .font(.system(size: 10))
                                , alignment: .topLeading
                            )

                        
                    }
                }
            
    }
}

struct First_Previews: PreviewProvider {
    static var previews: some View {
        First(selectedType: "1")
    }
}
