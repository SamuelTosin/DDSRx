//
//  ContentView.swift
//  DDD Rx Watch Watch App
//
//  Created by admin on 4/19/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView{
            ScrollView {
                VStack {
                    NavigationLink(destination: First(selectedType: "1")) {
                        Text("ANTIBIOTICS/PREMED Rx")
                            .font(.system(size: 10))
                            .foregroundColor(.green)
                    }
                    
                    NavigationLink(destination: Second(selectedType: "2")) {
                        Text("PAIN & ANXIOLYSIS Rx")
                            .font(.system(size: 10))
                            .foregroundColor(.green)
                    }
                    
                    NavigationLink(destination: Third(selectedType: "3")) {
                        Text("IRRIGATION & ANTICARIOUS Rx")
                            .font(.system(size: 10))
                            .foregroundColor(.green)
                    }
                    
                    NavigationLink(destination: Forth(selectedType: "4")) {
                        Text("ORAL FUNGUS/ VIRAL ALLERGIES")
                            .font(.system(size: 10))
                            .foregroundColor(.green)
                    }
                    
                    NavigationLink(destination: Fifth(selectedType: "5")) {
                        Text("PREGNANT / DRY MOUTH Rx")
                            .font(.system(size: 10))
                            .foregroundColor(.green)
                    }
                    
                    NavigationLink(destination: Fix(selectedType: "6")) {
                        Text("ERUPTION / IMPLANT/Rx Ref")
                            .font(.system(size: 10))
                            .foregroundColor(.green)
                    }
                    
                    NavigationLink(destination: Seven(selectedType: "7")) {
                        Text("ABOUT US")
                            .font(.system(size: 10))
                            .foregroundColor(.green)
                    }
                    
//                    NavigationLink(destination: Eight(selectedType: "8")) {
//                        Text("8. DONATE")
//                            .font(.system(size: 10))
//                            .foregroundColor(.green)
//                    }
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
