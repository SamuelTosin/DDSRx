//
//  Seven.swift
//  DDD Rx Watch Watch App
//
//  Created by admin on 4/19/23.
//

import SwiftUI

struct Seven: View {
    
    var selectedType: String
    
    var body: some View {
        List{
            Section {
                Text("ABOUT US")
                    .foregroundColor(.green)
                    .listRowBackground(Color.clear)
                    .padding(.top, -20)
                Text("DDS Rx is intended for use by dental professionals only. It is not intended for use by the general public or by individuals without proper training and qualifications in the field of dentistry. By using the DDS Rx app, the user confirms that they are a qualified dental professional and that they will only use the app for professional purposes. DDS Rx cannot be held liable for any misuse of the app by individuals who are not qualified dental professionals. Additionally, the user is responsible for ensuring that they comply with all applicable laws and regulations related to the use of the app in their jurisdiction. The user should also be aware of their professional responsibilities regarding the prescribing of drugs and should always consult other sources of information and seek the advice of a qualified professional before making any decisions based on the information provided by the app.\n\nThe DDS Rx application is to be used in conjunction with other prescription references. Other more extensive drug references are necessary for more comprehensive information detailing indications, contraindications, side effects, cross-drug interactions, as well as detailing the management of specific infections, diseases, medical conditions and side effects associated with the prescription of dental related drugs.\n\nDDS Rx is not liable for any clinical errors that may arise as a result of prescribing while using this app. It is the responsibility of the Dentist to know the drugs prescribed. Consequently, by using this app, you agree to assume all risks associated with using the app and its application. Use of this application regarding all information contained in the app, including prescribing information, is at your own risk and the user assumes all legal responsibility.\n\nCopyright @ 2023. All rights reserved.\n\nNo content on this app shall be transmitted or reproduced under any circumstances. Unauthorized distribution or reproduction will be prosecuted.\nPlease donate to help us develop more apps to benifit dental professionals").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .padding(.top, -20)
                
                Image("image_6487327")
                    .resizable()
                    .frame(width: 100, height: 100)
                    .scaledToFit()
                    .listRowBackground(Color.clear)

                
            }
        }
    }
}

struct Seven_Previews: PreviewProvider {
    static var previews: some View {
        Seven(selectedType: "7")
    }
}
