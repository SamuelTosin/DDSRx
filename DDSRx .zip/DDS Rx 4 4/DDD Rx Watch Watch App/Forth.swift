//
//  Forth.swift
//  DDD Rx Watch Watch App
//
//  Created by admin on 4/19/23.
//

import SwiftUI

struct Forth: View {
    
    var selectedType: String
    
    var body: some View {
        List {
            Text("ORAL PATHOLOGY/ALLEGIES").foregroundColor(.green).font(.system(size: 10))
                .padding(.top, -20)
                .multilineTextAlignment(.leading)
                .listRowBackground(Color.clear)
            Section(header: Text("FUNGUS INFECTIONS").foregroundColor(.red).font(.system(size: 10)).multilineTextAlignment(.leading).padding(.top, -20)){
                Text("\nDisp: 70 Troches\nSig: Dissolve 1 troche in mouth 5 times per day*\nContains sucrose caries risk\nContraindications: allergy\nSide effects: local irritat").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                        Text("Clotrimazole Troche (10 mg)")
                    .underline()
                    .font(.system(size: 10))
                , alignment: .topLeading
            )
                
                
                    .listRowBackground(Color.clear)
                Text("\nDisp:28 Tabs\nSig: Dissolve 1T in mouth q6h\nContraindications: allergy\nSide effects: nausea, diarrhea\nInteractions: none").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                        Text("Nystatin Tablets")
                    .underline()
                    .font(.system(size: 10))
                , alignment: .topLeading
            )
                
                Text("Dx: ANGULAR CHEILITIS").font(.system(size: 10))
                    .listRowPlatterColor(Color.clear)
                
                    .listRowBackground(Color.clear)
                Text("\n\nDisp: 15g\nSig: apply on corners q6h until result is achieved\nContraindications: allergy, fungal infection\nSide effects: skin thinning, irritation\nInteractions: none").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                        Text("Nystatin & Triamcinolone cream")
                .underline()
                .font(.system(size: 10))
                , alignment: .topLeading
            )
                
                Text("HERPES VIRAL INFECTIONSRx BY MOUTH").font(.system(size: 10))
                    .listRowPlatterColor(Color.clear)
                    .foregroundColor(.red)
                
                    .listRowBackground(Color.clear)
                Text("\nDisp:4 Tabs\nSig: Take 2T  at onset then 2T 10h later\nContraindications: HIV, renal/hepatic issues\nSide effects: headache, nausea\nInteractions: nephrotoxic drugs\n*Do not use for HIV patients or patients with renal or hepatic issues").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                        Text("Valtrex (100mg)")
                .underline()
                .font(.system(size: 10))
                , alignment: .topLeading
            )
            }
            
            Section {
                
                
                Text("\nDisp: 35 Tabs\nSig: Take 1T 5 times per day\nContraindications: allergy\nSide effects: nausea, headache\nInteractions: nephrotoxic drugs").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                        Text("Acyclovir (200mg)")
                .underline()
                .font(.system(size: 10))
                , alignment: .topLeading
            )

                
                Text("LOCALIZED TOPICAL Rx").foregroundColor(Color.red).font(.system(size: 10))
                    .listRowPlatterColor(Color.clear)
                Text("Zovirax Ointment 5%").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                Text("\nDisp: 16g\nSig: Apply q4h for 7d\nContraindications: allergy\nSide effects: local irritation\nInteractions: none\n*Do not use for renal or neurological impaired patients").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                        Text("Acyclovir (200mg)")
                .underline()
                .font(.system(size: 10))
                , alignment: .topLeading
            )
                
                
            }
        }
    }
}

struct Forth_Previews: PreviewProvider {
    static var previews: some View {
        Forth(selectedType: "4")
    }
}
