//
//  Second.swift
//  DDD Rx Watch Watch App
//
//  Created by admin on 4/19/23.
//

import SwiftUI

struct Second: View {
    
    var selectedType: String
    
    var body: some View {
        List {
            Text("PAIN & ANXIOLYSIS Rx").foregroundColor(.green).font(.system(size: 10))
                .multilineTextAlignment(.leading)
                .listRowBackground(Color.clear)
                .padding(.top, -20)
            Section(header: Text("MILD PAIN- OTC TYLENOL\nMODERATE PAIN- MOTRIN\nEXTREME PAIN- TYLENOL #3").foregroundColor(.white).font(.system(size: 10)).multilineTextAlignment(.leading).padding(.top, -20).underline()){
                Text("MILD PAIN - OVER THE COUNTER TYLENOL* or Rx")
                    .font(.system(size: 10))
                    .foregroundColor(.red)
                    .listRowBackground(Color.clear)
                
                Text("\nSig:16 tabs\nDisp:Take 2T q6h prn\nContraindications: liver disease\nSide effects: liver damage\nInteractions: alcohol, warfarin\n*Take as directed. Do not take more than 6 tablets a day. Do not take if history of liver disease or problems. TYLENOL is recommended for pregnant patients for emergencies. Ask physician before use.").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                        Text("Acetaminophen (500mg)*")
                            .underline()
                            .font(.system(size: 10))
                        , alignment: .topLeading
                    )
                .listRowPlatterColor(Color.clear)
                
                Text("MODERATE PAIN - MOTRIN* or NAPROXEN")
                    .font(.system(size: 10))
                    .foregroundColor(.red)
                    .listRowBackground(Color.clear)
                Text("\nDisp: 28 tabs\nSig: Disp:28 tabs\nSig: Take T q6h prn\nContraindications: ulcer, allergy\nSide effects: GI bleeding, kidney damage\nInteractions: anticoagulants, diuretics\n*Ulcer alert. Should be taken with water.").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                        Text("Motrin (600mg)*")
                            .underline()
                            .font(.system(size: 10))
                        , alignment: .topLeading
                    )
                
                
                Text("EXTREME PAIN- TYLENOL #3").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .foregroundColor(.red)

                Text("\nDisp 10 tabs\nSig: Take T q4h prn\nContraindications: respiratory depression, allergy\nSide effects: drowsiness, constipation\nInteractions: alcohol, CNS depressants\n*TYLENOL #3 is a mild narcotic. Please consult Licensing State guidelines and recommendations before prescribing.").font(.system(size: 10))
                    .overlay(
                        Text("Tylenol #3")
                            .underline()
                            .font(.system(size: 10))
                        , alignment: .topLeading
                    )
                    .listRowBackground(Color.clear)
                
                
                Text("\nDX: ANXIETY").font(.system(size: 10)).underline()
                    .overlay(
                        Text("ANXIOLYSIS")
                            .foregroundColor(.red)
                            .underline()
                            .font(.system(size: 10))
                        , alignment: .topLeading
                    )
                    .listRowBackground(Color.clear)
                
                    .listRowBackground(Color.clear)
                Text("\nDisp:4 Tabs\nSig: take 1T before bed and 1T one hour before visit\nContraindications: respiratory issues, allergy\nSide effects: drowsiness, dizziness\nInteractions: CNS depressants, alcohol\n*Pt needs transportation assistance. Not for pregnant pts.").font(.system(size: 10))
                    .listRowBackground(Color.clear)
                    .overlay(
                Text("Diazepam (5mg)*")
                    .underline()
                    .font(.system(size: 10))
                , alignment: .topLeading
            )
                
                
                
            }
            
        }
    }
}

struct Second_Previews: PreviewProvider {
    static var previews: some View {
        Second(selectedType: "2")
    }
}
